''' IP: [1,2,3,4,1,2,3,1,2]....
   OP: [[1 2 3 4 ],[1 2 3], [1 2]]
    ip:  [2,3,1,3,4,3,2]
    op:[[2 3 1 4],[3 2], [3]]
    ip: [4,5,2,1]
    op:[[4,5,2,1]]
   convert the given list as 2d list... in one occurence of list no repeat of number to bo written. no disticnt elemets to be found in a row.....'''


a=[2,3,1,3,4,3,2]
m=[]
c=0
while(c!=len(a)):
    r=[]
    for i in range(len(a)):
        if(not str(a[i]).isalpha()):
            if(a[i] not in r):
                c=c+1
                r.append(a[i])
                a[i]='a'
    m.append(r)
print(m)

#using dictionary concept.......

a=[a,a,a,a,a,a,a,a,a]
d={}
m=[]
c=0
for i in a:
    if(i not in d):
        d[i]=1
    else:
        d[i]=d[i]+1
    
