#tree concept binary search tree , traversals.....
'''class node:
    def _init_(self,u):
        self.data=u
        self.left=None
        self.right=None
class tree:
    def _init_(self):
        self.root=None
    def creat(self,root,x):
        if(root==None):
            self.root=node(x)
        elif(self.root.data>x):
            self.creat(root.left,x)
        else:
            self.creat(root.right,x)
    def inorder(root):
        if(root):
            inorder(root.left)
            print(root.data)
            inorder(root.right)
    def preorder(root):
        if(root):
            print(root.data)
            preorder(root.left)
            preorder(root.right)
t1 =tree()
t1.creat(t1.root,10)
t1.creat(t1.root,5)
t1.creat(t1.root,20)
t1.creat(t1.root,7)
t1.creat(t1.root,1)
print(t1)'''


class Node:
    def __init__(self, u):
        self.data = u
        self.left = None
        self.right = None

class Tree:
    def __init__(self):
        self.root = None

    def create(self, root, x):
        if root is None:
            return Node(x)
        elif x < root.data:
            root.left = self.create(root.left, x)
        else:
            root.right = self.create(root.right, x)
        return root

    def insert(self, x):
        self.root = self.create(self.root, x)

    def preorder(self, node):
        if node:
            print(node.data, end=' ')
            self.preorder(node.left)
            self.preorder(node.right)

    def inorder(self, node):
        if node:
            self.inorder(node.left)
            print(node.data, end=' ')
            self.inorder(node.right)

    def postorder(self, node):
        if node:
            self.postorder(node.left)
            self.postorder(node.right)
            print(node.data, end=' ')
t1 = Tree()
t1.insert(10)
t1.insert(5)
t1.insert(20)
t1.insert(7)
t1.insert(1)
print("Preorder Traversal:")
t1.preorder(t1.root)  

print("\nInorder Traversal:")
t1.inorder(t1.root)

print("\nPostorder Traversal:")
t1.postorder(t1.root))

