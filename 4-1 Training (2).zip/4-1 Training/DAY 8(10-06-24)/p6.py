'''word puzzle problem....using backtracking concept
ip:
       4
       t u e d
       f w o w
       r o e r
       d r u i
       word
op:
         yes
