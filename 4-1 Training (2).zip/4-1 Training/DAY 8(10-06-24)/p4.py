'''find the char occurences in the string given using dicionary with key as alaphbets and value as the occurence of alphabets number
 ip:"abfgresagtyuiofds"
 op:
     {a:4;b:1,c:0,d:1}
'''
def count_char_occurrences(s):
    char_count = {chr(i): 0 for i in range(ord('a'), ord('z') + 1)}

    for char in s:
        if char in char_count:
            char_count[char] += 1
    
    return char_count

input_string = "abfgresagtyuiofds"

result = count_char_occurrences(input_string)

print(result)


