''' FOR THE GIVEN INPUT NUM, FIND THE FACTOSRS AT THE POSITION OF KEY VALUE
    IP:
    12
    3
    1   2   3   6   12
    OP:
    3     IF KEY=4     THEN   OP:   6'''
a=12
c=3
d,e=0,0
for i in range(a,0,-1):
    if a%i==0:
        d=1
        e+=1
    if e==c:
        print(d)
