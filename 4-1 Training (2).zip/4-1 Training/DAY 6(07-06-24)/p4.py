#take two numbers from user and check whether the nums are co-prime or not..
'''
import math
a = int(input())
b = int(input())
def are_coprime(a,b):
    return math.gcd(a, b) == 1
if are_coprime(a, b):
    print("coprime.")
else:
    print("coprime.")'''


import math
a=int(input())
b=int(input())
print(math.gcd(a,b)==1)
