'''take a string from the user find the error in the valid paranthesis
   ip:
   "(([{}]))"
   op:
   -1
   ip:
   "[{()]]"
   op:
   5.... error at fifth position'''

#using linked list....
class Node:
    def __init__(self, value, position):
        self.value = value
        self.position = position
        self.next = None

class Stack:
    def __init__(self):
        self.top = None

    def push(self, value, position):
        new_node = Node(value, position)
        new_node.next = self.top
        self.top = new_node

    def pop(self):
        if self.top is None:
            return None
        popped_node = self.top
        self.top = self.top.next
        return popped_node

    def peek(self):
        if self.top is None:
            return None
        return self.top.value

    def is_empty(self):
        return self.top is None

    def get_top_position(self):
        if self.top is None:
            return None
        return self.top.position

def find_parenthesis_error(string):
    stack = Stack()
    matching_parenthesis = {')': '(', '}': '{', ']': '['}

    for i, char in enumerate(string):
        if char in '({[':
            stack.push(char, i)
        elif char in ')}]':
            if stack.is_empty() or stack.peek() != matching_parenthesis[char]:
                return i  
            stack.pop()
    
    if not stack.is_empty():
        return stack.get_top_position()  

    return -1  

print(find_parenthesis_error("(([{}]))")) 
print(find_parenthesis_error("[{()]]")) 
'''
#using stack

n = input("Enter the string: ")

def valid_parenthesis(s):
    stack = []
    opening_brackets = "({["
    closing_brackets = ")}]"
    matching_bracket = {')': '(', '}': '{', ']': '['}
    
    for i, c in enumerate(s):
        if c in opening_brackets:
            stack.append((c, i))
        elif c in closing_brackets:
            if stack and stack[-1][0] == matching_bracket[c]:
                stack.pop()
            else:
                return i + 1  
    
    if stack:
        return stack[-1][1] + 1  
    
    return -1  

res = valid_parenthesis(n)
print(res)
'''
