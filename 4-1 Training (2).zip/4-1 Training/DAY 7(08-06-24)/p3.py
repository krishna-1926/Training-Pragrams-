''' ip: school
         3
         L --2  --------->hoolsc
         R--3   ----------->oolsch
         L--1     ------------ >chools
    op:
           yes
           hoc
    subsequence of a given string , sch,cho,hoo,ool.....
    check whether the word is an anagram or not from the subsequences..........'''

a=input()
n=int(input())
s=""
for i in range(n):
    b=input()
    if b[0]=='L':
        s+=a[-int(b[2])]
    else:
        s+=a[-int(b[2])]
print(s)
s=list(s)
s.sort()
b=[]
for i in range(len(a)-n+1):
    t=list(a[i:n+i])
    t.sort()
    b.append(t)
print(b)
print(s)
for i in b:
    if i==s:
        print('yes')
        break

    
