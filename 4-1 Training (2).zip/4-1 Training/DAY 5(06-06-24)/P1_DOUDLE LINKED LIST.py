#DOUBLE LINKED LIST....
class Node:
    def __init__(self,n):
        self.data=n
        self.next=None
        self.prev=None
class dll:
    def __init__(self):
        self.head=None
        self.tail=None
    def addback(self,x):
        if self.head==None:
            self.head=Node(x)
            self.tail=self.head
        else:
            t=Node(x)
            self.tail.next=t
            t.prev=self.tail
            self.tail=self.tail.next
    def addfront(self,x):
        if self.head==None:
            self.head=Node(x)
            self.tail=self.head
        else:
            t=Node(x)
            t.next=self.head
            self.head.prev=t
            self.head=t
    def display(self):
        t=self.head
        while t!=None:
            print(t.data,end="->")
            t=t.next
        print()
    def rev_display(self):
        t=self.tail
        while t!=None:
            print(t.data,end="->")
            t=t.prev
        print()
    def search(self,x):
        t=self.head
        a=self.tail
#         while t is not None:
#             if t.data==x:
#                 print("found")
#                 break
#             t=t.next
#         print('not found')
        while t !=a and t!=a.next :
            if t.data==x or a.data==x:
                return 1
                break
         
            t=t.next
            a=a.prev
        if t.data==x:
            return 1
        else:
            return 0
        
    def lengthl(self):
        t=self.head
        a=self.tail
        while t!=a and t!=a.next:
            if t==a:
                return 1
            t=t.next
            a=a.prev
        if t==a:
            return 1
        else:
            return 0
    def palin(self):
        t=self.head
        a=self.tail
        while t!=a and t!=a.next:
            if t.data!=a.data:
                print('not palindrome')
                return 
            t=t.next
            a=a.prev
            
        print('yes it is palindrome')
    def rotatel(self):
        s=f=self.head
        while f and f.next:
            s=s.next
            f=f.next.next
        print(s.data)
        f=self.head
        while s.next is not None:
            
#             do by links
            s.data,f.data=f.data,s.data 
            f=f.next
            s=s.next
    def reverse(self):
        t=self.head
        prev=None
        while t is not None:
            next_n=t.next
            t.next=prev
            prev=t
            t=next_n
        self.head=prev
        

     
l=dll()
l.addback(9)
# l.addfront(1)
l.addback(10)
l.addback(11)
l.addback(12)
# l.addfront(10)
# l.addfront(1)
l.display()
# l.rev_display()
# print(l.search(5))
# if l.lengthl():
#     print("even")
# else:
#     print("odd")
# l.palin()
# l.rotatel()
print()
l.reverse()
l.display()
