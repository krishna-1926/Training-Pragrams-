''' graph represented in the form of dictionary..
 ip:  {5:[7,3],7:[5,3,4],3:[5,8],4:[7,8,2],8:[4,3,2],2:[4,8]}

   fun(5,l):
   l.append(5)
   for i in d[5]:(7,3)
   if(i not in l):
   fun(i,l)
print the path of the graph
op:
     [5,7,4,8,3,2]
   '''
#path printing

'''def fun(d, a, l):
    if a not in l:
        l.append(a)
        for i in d[a]:
            fun(d, i, l)
d = {5: [7, 3], 7: [5, 4, 3], 4: [7, 8, 2], 8: [3, 4, 2], 3: [5, 7, 8], 2: [4, 8]}
l = []
fun(d, 5, l)
print(l)'''

#possible path 

'''def find_all_paths(d, start, end, path=[]):
    path = path + [start] 
    if start == end:
        return [path]
    if start not in d:
        return [] 
    paths = []  
    for node in d[start]: 
        if node not in path:  
            newpaths = find_all_paths(d, node, end, path)  
            for newpath in newpaths:
                paths.append(newpath)  
    return paths

d = {5: [7, 3], 7: [5, 4, 3], 4: [7, 8, 2], 8: [3, 4, 2], 3: [5, 7, 8], 2: [4, 8]}

all_paths = find_all_paths(d, 5, 2)
for path in all_paths:
    print(path)


#cost of the graph
def find_all_paths_with_costs(d, start, end, path=[], cost=0):
    path = path + [start] 
    if start == end:
        return [(path, cost)]  
    if start not in d:
        return [] 
    paths = []  
    
    for (node, weight) in d[start]:  
        if node not in path: 
            newpaths = find_all_paths_with_costs(d, node, end, path, cost + weight) 
            for newpath in newpaths:
                paths.append(newpath)  
    return paths

d = {
    5: [(7, 2), (3, 3)],
    7: [(5, 2), (4, 1), (3, 2)],
    4: [(7, 1), (8, 3), (2, 1)],
    8: [(3, 2), (4, 3), (2, 2)],
    3: [(5, 3), (7, 2), (8, 2)],
    2: [(4, 1), (8, 2)]
}

all_paths_with_costs = find_all_paths_with_costs(d, 5, 2)
for path, cost in all_paths_with_costs:
    print(f"Path: {path}, Cost: {cost}")'''


#finding min cost and path as output

'''def fun(d,x,e,c,m,l1):
    l.append(x)
    if(x==e):
        if(c<m):
            m=c
            l1=l.copy()
        l.pop()
        return m,l1
    for i in d[x]:
        if i[0] not in l:
            m,l1=fun(d,i[0],e,c+i[1],m,l1)
    l.pop()
    return m,l1
d = {
    5: [(7, 2), (3, 3)],
    7: [(5, 2), (4, 1), (3, 2)],
    4: [(7, 1), (8, 3), (2, 1)],
    8: [(3, 2), (4, 3), (2, 2)],
    3: [(5, 3), (7, 2), (8, 2)],
    2: [(4, 1), (8, 2)]
}
l=[]
print(fun(d,5,2,0,99999,[]))'''

#all possible paths
def find_all_paths(d, start, end, path=[]):
    path = path + [start] 
    if start == end:
        return [path]
    if start not in d:
        return [] 
    paths = []  
    for node in d[start]: 
        if node not in path:  
            newpaths = find_all_paths(d, node, end, path)  
            for newpath in newpaths:
                paths.append(newpath)  
    return paths

d = {5: [7, 3], 7: [5, 4, 3], 4: [7, 8, 2], 8: [3, 4, 2], 3: [5, 7, 8], 2: [4, 8]}

all_paths = find_all_paths(d, 5, 2)
for path in all_paths:
    print(path)
all_paths = find_all_paths(d, 5, 7)
for path in all_paths:
    print(path)
    all_paths = find_all_paths(d, 5, 3)
for path in all_paths:
    print(path)
    all_paths = find_all_paths(d, 5, 8)
for path in all_paths:
    print(path)
    all_paths = find_all_paths(d, 5, 4)
for path in all_paths:
    print(path)


#BFS Code

def fun(d,x):
    v=[]
    q=[x]
    while(q):
        for i in d[q[0]]:
            if i not in v and i not in q:
                q.append(i)
        v.append(q.pop(0))
        return v
    
    
#d={5:[7,3],7:[5,4,3],4:[7,8,2],3:[5,7,8],8:[3,4,2],2:[4,8]}
d={1:[2,3,7],2:[5,10,4],3:[6,7],4:[2,10,9],5:[2],6:[3],7:[8,3],8:[7],9:[4],10:[4,2,11],11:[10]}
print(fun(d,next(iter(d))))

#drikstra's Algorithm......

def fun(g,x):
    #d={5:9999,1:9999,3:9999,6:9999,2:9999,8:9999,7:9999,9:9999,4:9999}
    d={5:9999,3:9999,2:9999,8:9999,7:9999,4:9999}
    d[x]=0
    vi=[]
    q=[x]
    while(q):
        m=9999
        for i in q:
            if(d[i]<m):
                m=d[i]
                x=i
        for i in g[x]:
            if(i[0] not in vi):
                if i[0] not in q:
                    q.append(i[0])
                if d[i[0]]>i[1]+d[x]:
                    d[i[0]]=i[1]+d[x] 
        vi.append(x)
        q.remove(x)
    
    print(vi)
    print(d)
#g={5:[(2,2),(3,2),(8,2)],2:[(5,2),(3,1)],3:[(5,2),(2,1),(7,3),(8,3)],8:[(5,2),(6,4),(3,3)],6:[(8,4),(9,2)],7:[(3,3),(9,1)]
 #    ,9:[(6,2),(7,1,),(4,2)],4:[(9,2)]}

g={5:[(7,1),(3,3)],7:[(5,1),(4,3),(3,2)],4:[(7,3),(8,6),(2,3)],8:[(3,5),(4,6),(2,2)],3:[(5,3),(7,2),(8,5)],2:[(4,3),(8,2)]}



fun(g,next(iter(g))).321  


