'''''
ip: asd!@#               ip:A1234B
op:1                           op:2
---------------
ip: 123456789            ip:A1234a@4
op:3                           op:-1
---------------
'''''
#create password using the rules and print the output the count to make a prefect password

c=0
for i on range(2,(n//2)+1):
    if(n%i==0):
        c=c+1
        break
if(c==0):
    print(n)
    break
else:
    n=n+1




