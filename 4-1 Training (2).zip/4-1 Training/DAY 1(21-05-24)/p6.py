'' ''' ip: 5  3.8  7  5.6   4   2  3
       op:
       15
       6
       9.4
add even separate , odd numbers ,float numbers separate
'' '''

