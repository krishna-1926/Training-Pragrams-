a=[2,5,7,9]
b=[1,3,6,7,10,13]
i=0
j=0
c=[]
while(i<len(a) and j<len(b)):
    if(a[i]<b[j]):
        c.append(a[i])
        i=i+1
    else:
        c.append(b[j])
        j=j+1
if(j<len(b)):
    c.extend(b[j:])
if(i<len(a)):
    c.extend(a[i:])
print(c)
