'''' ''ip : f46feLK9y56@&56ghySFHD
      op:
      lv(lowercase vowels)
      uv(uppercase vowels)
      lc(lowercase constants)
      uc(uppercase constants)
      d(digits)
      s(special char) "" "
'''' '
input_string = "f46feLAK9y56@&56ghySFHD"
lv = ""
uv = ""
lc = ""
uc = ""
d = ""
s = ""
lowercase_vowels = "aeiou"
uppercase_vowels = "AEIOU"

for char in input_string:
    if char in lowercase_vowels:
        lv += char
    elif char in uppercase_vowels:
        uv += char
    elif char.islower():
        lc += char
    elif char.isupper():
        uc += char
    elif char.isdigit():
        d += char
    else:
        s += char
    #elif not i.isalnum():
        #s=s+1   (to print only special char in a string given )
print(len(lv))
print(len(uv))
print(len(lc))
print(len(uc))
print(len(d))
print(len(s))
