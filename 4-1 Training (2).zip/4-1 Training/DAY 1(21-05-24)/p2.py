#string count sort .. input= aaabbaaaaddd, output=a3b2a4d3
ints = "aaabbaaaaddd"
out = ""
i = 0
while i < len(ints):
    current_char = ints[i]
    c = 1
    while i + 1 <  len(ints) and ints[i + 1] == current_char:
        c += 1
        i += 1
    out+= current_char + str(c)
    i += 1
print(out)

###
a="aaabbaaaaddd"
c=1
b=''
for i in range(len(a)-1):
    if(a[i] ==a[i+1]:
       c=c+1
    else:
        b=b+a[i]+str(c)
        c=1
b=b+a[i+1]+str(c)
print(b)
#a[-1] and a[i] only comes for this, not for other string sets
