#count the occurences in the list of numbers i/p: 3,4,7,9,8,8,6,4,3,5...o/p:3-2.. 4-2.. 7-1.. 9-1.. 8-2...
a=[3,4,9,7,8,3,8,6,4,3,5]
b=[]
for i in a:
    if(i not in b):
        b.append(i)
for i in b:
    print(i,"-",a.count(i))
    
