'' '' '''''ip: 300  400
          op: inclusive disply count of numbers divisible by 7
          '''''
s= 300
e = 400
c = 0
for n in range(s, e + 1):
    if n % 7 == 0:
        c += 1
print( c)

'''''a=(300/7) -(400/7)
     print(a)
     '''''
