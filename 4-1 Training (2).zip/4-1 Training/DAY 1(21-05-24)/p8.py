#prime number  check, if yes print that num else, print the next consecutive prime number   ip: 14  op: 17... ip:13  op: 13...

n=int(input())
while(1):
    c=0
    for i in range(2,(n//2)+1):
        if(n%i==0):
            c=c+1
            break
    if(c==0):
        print(n)
        break
    else:
        n=n+1
