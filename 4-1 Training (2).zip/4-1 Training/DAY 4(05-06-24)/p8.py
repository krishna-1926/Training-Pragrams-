'''write a program to print all the pairs of a list given using linked list........
     ip: 6  7   4  8  4  9   0  1
     op:  67    64   68    64   69   60  61
             74    78   74    79   70   71
             48    44     49   40  41
             84   89     80    81
             49   40    41
             90   91
             01

class ListNode:
    def __init__(self, value=0, next=None):
        self.value = value
        self.next = next

def print_pairs(head):
    current = head
    elements = []

    while current:
        elements.append(current.value)
        current = current.next

    for i in range(len(elements)):
        for j in range(i + 1, len(elements)):
            print(f"{elements[i]}{elements[j]}", end=" ")
        print()

def create_linked_list(values):
    if not values:
        return None
    head = ListNode(values[0])
    current = head
    for value in values[1:]:
        current.next = ListNode(value)
        current = current.next
    return head

values = [6, 7, 4, 8, 4, 9, 0, 1]
head = create_linked_list(values)

print_pairs(head)'''


#linked list finding the all pairs  of linked list......
class node:
    def __init__(self,u):
        self.data=u
        self.nxt=None
class sll:
    def __init__(self):
        self.head=None
    def display(self):
        t =self.head
        while(t != None):
            print(t.data,end="->")
            t = t.nxt
    def addback(self,x):
        t=self.head
        while (t.nxt!= None):
            t=t.nxt
        t.nxt = node(x)
    def addeven(self):
        t=self.head
        s=0
        while(t!=None):
            if(t.data%2==0):
                s+=t.data
                t=t.nxt
        print(s)
    def addmiddle_evenod(self):
        F=self.head
        S=self.head
        while F and F.nxt:
            S=S.nxt
            F=F.nxt.nxt
        print(S.data)
    def search(self,x):
        t=self.head
        while(t!=None):
            if (t.data==x):
                return "found"
            t=t.nxt
        return "not found"
    def allpairs(self):
        t=self.head
        while(t.nxt!=None):
            t1=t.nxt
            while(t1!=None):
                print(t.data,t1.data)
                t1=t1.nxt
            t=t.nxt
l1=sll() 
l2=sll() 
l1.head = node(10)
l1.addback(20)
l1.addback(30)
l1.addback(40)
l1.addback(50)
l1.addback(60)
l1.addback(70)
l2.head=node(100)
l2.addback(200)
l2.addback(300)
l1.display()
l1.allpairs()
print()
l2.display()
print()
l1.addeven()
print(l2.search(100))
print(l1.addmiddle_evenod())
print(l2.addmiddle_evenod())
