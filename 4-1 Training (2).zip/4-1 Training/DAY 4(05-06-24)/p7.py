'''find the longest string length consequtive of num string.
    12347893456789 using linked list ....'''
class ListNode:
    def __init__(self, value=0, next=None):
        self.value = value
        self.next = next

def find_longest_consecutive(head):
    if not head:
        return 0, ""

    max_length = 1
    current_length = 1
    max_start = head
    current_start = head

    current = head.next

    while current:
        if int(current.value) == int(current_start.value) + 1:
            current_length += 1
        else:
            if current_length > max_length:
                max_length = current_length
                max_start = current_start

            current_start = current
            current_length = 1

        current_start = current
        current = current.next

    if current_length > max_length:
        max_length = current_length
        max_start = current_start

    # Extract the longest consecutive substring
    longest_consecutive_str = ""
    for _ in range(max_length):
        longest_consecutive_str += str(max_start.value)
        max_start = max_start.next

    return max_length, longest_consecutive_str

# Helper function to create a linked list from a string of values
def create_linked_list_from_string(s):
    if not s:
        return None
    head = ListNode(s[0])
    current = head
    for char in s[1:]:
        current.next = ListNode(char)
        current = current.next
    return head

# Example usage:
input_string = "12347893456789"
head = create_linked_list_from_string(input_string)
length, longest_consecutive_str = find_longest_consecutive(head)
print(f"Longest consecutive substring: {longest_consecutive_str}, Length: {length}")
