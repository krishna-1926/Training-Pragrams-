#linked list _ all functions.....

class Node:
    def __init__(self,u):
        self.data=u
        self.next=None
class SLL:
    def __init__(self):
        self.head=None
    def display(self):
        t=self.head
        while(t!=None):
            print(t.data,end="->")
            t=t.next
        
    def addback(self,x):
        t=self.head
        while(t.next!=None):
            t=t.next
        t.next=Node(x)
        
    def addfront(self,x):
        t=self.head
        n_node=Node(x)
        
        n_node.next=self.head
        self.head=n_node
        
    
    def addeven(self):
        s=0
        t=self.head
        while(t!=None):
            if t.data%2==0:
                s+=t.data
            t=t.next
        print(s)
    def search(self,x):
        t=self.head
        while t is not None:
            
            if t.data==x:
                return "found"
            t=t.next
        return "not found"
    def middle(self):
        s=f=self.head
        while f and f.next:
            s=s.next
            f=f.next.next
            
        print(s.data)
    def findlength(self):
        f=self.head
        while f :
            f=f.next.next
            if f is  None:
                return 'odd'
            else:
                return "even"
    def logsub(self):
        c=1
        c1=0
        t=self.head
        while t.next is not None:
            
            if t.data == t.next.data-1:
                c+=1
            else:
                if c>c1:
                    c1=c
            t=t.next
        if c>c1:
            c1=c
        print(c1)
        
    def pairsl(self):
        t=self.head
        
        while t.next is not None:
            t1=t.next
            while t1 is not None:
                print(t.data,t1.data)
                t1=t1.next
                
            t=t.next
         
    def bublesort(self):
        p=None
        t=self.head
        while t.next is not None:
            f=0
            t1=self.head
            while t1.next!=p: 
                
                if t1.data>t1.next.data:
                    f=1
                    t1.data,t1.next.data=t1.next.data,t1.data
                t1=t1.next
            if f==0: #to save no.of iterations
                break 
            t1=p #to save no.of iterations
            t=t.next

        
      
l=SLL()
l.head=Node(1)
l.addback(2)
l.addback(3)
l.addfront(4)
l.addfront(5)
l.addfront(8)
l.display()
print()
# l.addeven()
# print(l.search(20))
# l.middle()
# print(l.findlength())

# l.logsub()
# l.pairsl()
l.bublesort()
l.display()
