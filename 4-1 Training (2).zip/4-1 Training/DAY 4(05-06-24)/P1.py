#class and inheritance concepts....
''''class qwer:
    def __init__(self,v,u):
        a=u
        b=v
    def asd(self):
        print("helllo",self.a)
        x.zxc()
    def zxc(self):
        print("hi",self.b)

x=qwer(20,40)
y=qwer(50,10)
y.asd()'''
'''
class qwer:
    def __init__(self,v,u):
        self.a=u
        self.b=v
    def asd(self):
        print("helllo",self.a)
        x.zxc()
    def zxc(self):
        print("hi",self.b)

x=qwer(20,40)
y=qwer(50,10)
y.asd()'''


class qwer:
    def __init__(self,v,u):
        self.a=u
        self.b=v
    def asd(self):
        print("helllo",self.a+x,self.b)
        y.zxc(x+10)
    def zxc(self,y):
        print("hi",self.b+y,self.a)

x=qwer(40,10)
y=qwer(50,10)
y.asd(60)
