#linked list concept...........
'''class node:
    def __init__(self,u):
        self.data=u
        self.nxt=None
a=node(10)
b=node(20)
print(a.data,a.nxt)
print(b.data,b.nxt)
'''
'''
class node:
    def __init__(self,u):
        self.data=u
        self.nxt=None
a=node(10)
b=node(20)
c=node(30)
a.nxt=b
b.nxt=c
print(a.data,a.nxt)
print(b.data,b.nxt)
print(c.data,c.nxt)'''


class node:
    def __init__(self,u):
        self.data=u
        self.nxt=None
head=node(10)
head.nxt=node(20)
head.nxt.nxt=node(30)
head.nxt.nxt.nxt=node(40)
print(head.data)
print(head.nxt.data)
print(head.nxt.nxt.data)
print(head.nxt.nxt.nxt.data)

