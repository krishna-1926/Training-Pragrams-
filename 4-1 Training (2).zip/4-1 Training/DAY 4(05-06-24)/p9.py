#bubble sort implementation on a linked list
'''
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = Node(data)
        if self.head is None:
            self.head = new_node
            return
        last = self.head
        while last.next:
            last = last.next
        last.next = new_node

    def print_list(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

    def bubble_sort(self):
        end = None
        while end != self.head:
            current = self.head
            while current.next != end:
                next_node = current.next
                if current.data > next_node.data:
                  
                    current.data, next_node.data = next_node.data, current.data
                current = next_node
            end = current

ll = LinkedList()
ll.append(4)
ll.append(3)
ll.append(1)
ll.append(2)

print("Original list:")
ll.print_list()  

ll.bubble_sort()

print("Sorted list:")
ll.print_list()  '''


class node:
    def __init__(self,u):
        self.data=u
        self.nxt=None
class sll:
    def __init__(self):
        self.head=None
    def display(self):
        t =self.head
        while(t != None):
            print(t.data,end="->")
            t = t.nxt
    def addback(self,x):
        t=self.head
        while (t.nxt!= None):
            t=t.nxt
        t.nxt = node(x)
    def addeven(self):
        t=self.head
        s=0
        while(t!=None):
            if(t.data%2==0):
                s+=t.data
                t=t.nxt
        print(s)
    def addmiddle_evenod(self):
        F=self.head
        S=self.head
        while F and F.nxt:
            S=S.nxt
            F=F.nxt.nxt
        print(S.data)
    def search(self,x):
        t=self.head
        while(t!=None):
            if (t.data==x):
                return "found"
            t=t.nxt
        return "not found"
    def bubble(self):
        c=0
        T=self.head
        p=None
        while(T.nxt!=None):
            f=0
            t=self.head
            while(t.nxt!=p):
                if(t.data>t.nxt.data):
                    f=1
                    t.data,t.nxt.data=t.nxt.data,t.data
                t=t.nxt
                c=c+1
            if(f==0):
                break
            p=t
            T=T.nxt
        return c
     
l1=sll() 
l2=sll() 
l1.head = node(10)
l1.addback(80)
l1.addback(30)
l1.addback(40)
l1.addback(20)
l1.addback(60)
l1.addback(70)
l2.head=node(100)
l2.addback(200)
l2.addback(300)
l1.display()
print()
l2.display()
print()
l1.addeven()
print(l2.search(100))
print(l1.addmiddle_evenod())
print(l2.addmiddle_evenod())
l1.display()
print()
l1.bubble()
print()
l1.display()


