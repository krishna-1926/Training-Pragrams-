''' ip:  [4,8,14,22,36,68]
find the highest prime number between two adjacent pairs and print sum of all highest prime  nos... as output
  op:  7  13  19   31  67
         107'''
def check_prime(n):
    for i in range(2,n//2):
        if n%i==0:
            return 0
    if 2==n//2:
        return 0
    return 1

def lar_prime(n1,n2):
    for i in range(n2-1,n1,-1):
        if check_prime(i)==1:
            return i
        return 0
        
li=[14,16,20,22]
#li=[4,8,14,22,36,68]
# li=[1,5,9,44,56,64]
res=[]

for i in range(len(li)-1):
    res.append(lar_prime(li[i],li[i+1]))
print(res)
print(sum(res))


'''def isprime(x):
    for i in range(2,(x//2)+1):
        if(x%i==0):
            return 0
    return 1
            
def lprime(n,m):
    for i in range(m-1,n,-1):
        if(isprime(i)):
            return i
    return 0


a=list(map(int,input().split()))
s=0
for i in range(len(a)-1):
    s=s+lprime(a[i],a[i+1])
print(s)
         
