''' ip:  [4,9,8,2,14,3,5,6]
  take first three numbers and sort as ascending order and then to next..
 op:  [4,2,8,3,5,6,9,14]'''

a=list(map(int,input().split()))
for i in range(len(a)-2):
    if(a[i]>a[i+1]):
        a[i],a[i+1]=a[i+1],a[i]
    if(a[i+1]>a[i+2]):
        a[i+1],a[i+2]=a[i+2],a[i+1]
    if(a[i]>a[i+1]):
        a[i],a[i+1]=a[i+1],a[i]
print(a)

