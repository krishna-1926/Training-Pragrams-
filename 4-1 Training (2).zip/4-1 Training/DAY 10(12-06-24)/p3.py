''' ip:  "hello:5438, car:214, book:8798,apple:2187"
   op:   oaxp
   for the length of word string , print the corresponding char...
   if not present print the num with less than the lemgth of string...
   if less than not present, print x as char...
   eg: 5-->hello
         return o
         3--->car
         2  less than no
         4--->book
         no less num
         return x
         5---->apple
         less number 2
         return p
         '''
a=input().split(',')
s=' '
for i in a:
    b=i.split(":")
    l=len(b[0])
    if(str(l) in b[1]):
        s=s+b[0][-1]
    else:
        for i in range(l-1,0,-1):
            if(str(i) in b[1]):
                s=s+b[0][i-1]
                break
        else:
            s=s+'x'
print(s)

