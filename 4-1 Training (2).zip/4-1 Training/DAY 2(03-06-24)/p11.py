#leetcode- 1859------------sorting of sentence
'''input- s=is2 sentence4 this1 a3
 ouput:  " this is a sentence"
 '''
a=input().split()
re=[0]*len(a)
for i in a:
    re[int
