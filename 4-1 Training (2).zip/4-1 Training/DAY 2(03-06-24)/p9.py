#in the string of female n male, if both are equal op=0, if F count is more than M count ---op=F, else M count is more ----op=M
def fm(s):
    count_F = s.count('F')
    count_M = s.count('M')
    
    if count_F == count_M:
        return 0
    elif count_F > count_M:
        return 'F'
    else:
        return 'M'

print(fm("FMFMFMM"))

#sir code
'''a="MFMMMMFMFMMFMFMMFMMF"
c=0
for i in a:
    if(i=='M'):
        c=c+1
    else:
        c=c-1
'''
