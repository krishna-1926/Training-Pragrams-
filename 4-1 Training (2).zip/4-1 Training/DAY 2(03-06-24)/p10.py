#input- s="leet**cod*e.... output- "lecoe"

s="leet**cod*e"
a=[]
for i in s:
    if(i !='*'):
        a.append(i)
    else:
        a.pop()
print(''.join(a))

'''
#other source of solving using stack....

z='leet**cod*e'
for i in z:
    if i=='*':
        stack.pop()
    else:
        stack.append(i)
    z="".join(stack)
print(z)
'''
