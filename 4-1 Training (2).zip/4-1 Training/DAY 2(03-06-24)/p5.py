#if input is 10, print the sum of all even numbers from  1 to 10 using recursion...
''''s=0
for i in range(1,11):
    if (i%2==0):
        s=s+i
print(s)''''

#using recursion
def fa(x):
    if(x==0):
        return 0
    return x+fa(x-2)
print(fa(10))

''''
for n=odd num, above prog run only for even input... as x accepts the even number input only...
n=13
if(n%2==0):
    print(fa(n))
else:
    print(fa(n-1))
'''''
