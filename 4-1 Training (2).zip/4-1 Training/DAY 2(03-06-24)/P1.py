# 578 being a number - getting to single digit and checking if it is prime or not .. if not find the next prime no sum..
def sum_of_digits(number):
    while number >= 10:  
        number = sum(int(digit)
        for digit in str(number))  
    return number

number = 540
result = sum_of_digits(number)
print(result)
while(1):
        c=0
        for i in range(2,(result//2)+1):
            if(result%i==0):
                c=c+1
                break
        if(c==0):
            print(result)
            break
        else:
            result=result+1
''''        
def add(n):
    s=0
    while(n):
        s=s+(n%10)
        n=n//10
    return s
def pnp(x):
    if(n in [2,3,5,7]):
        return m
    else:
        return m+1
n=int(input())
m=n
while():
    if(n<10):
        print(pnp(n))
    else:
        while(1):
            n=add(n)
            if(n<10):
                break
        print(pnp(n))
    '''''
