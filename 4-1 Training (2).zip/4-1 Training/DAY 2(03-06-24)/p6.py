#for a given list , print yes if length of list is even ,else no
a=[5,8,9,6,4,2,3,7]
if(len(a)%2==0):
    print ("yes")
else:
    print("no")
'''''
