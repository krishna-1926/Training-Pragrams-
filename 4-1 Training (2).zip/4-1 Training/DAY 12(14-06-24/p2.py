''' take two lists and match the l1 even numbers with l2 odd numbers and print those sum as output
  l1=[6,3,2,9,4,7]
  l2=[8,7,5,3,6,9]

  output: [13,11,9,15,9,7,5,11,11,9,7,13]
  '''

def even_num(lst):
    return [num for num in lst if num % 2 == 0]

def odd_num(lst):
    return [num for num in lst if num % 2 != 0]

def sum(evens, odds):
    if not evens or not odds:
        return []
    return [evens[0] + odd for odd in odds] + sum(evens[1:], odds)

l1 = [6, 3, 2, 9, 4, 7]
l2 = [8, 7, 5, 3, 6, 9]

even_l1 = even_num(l1)
odd_l2 = odd_num(l2)

res = sum(even_l1, odd_l2)
print(res)



