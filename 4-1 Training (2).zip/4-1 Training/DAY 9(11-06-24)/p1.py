# print of sum of elements of the traversal in binary search tree
#program to print even sum and odd sum of elements in subtree
#height of tree
#balanced tree
#count of leaf nodes
#sum of leaf nodes
#search an element in tree
#finding depth of a tree from an element

class Node:
    def __init__(self, u):
        self.data = u
        self.left = None
        self.right = None

class Tree:
    def __init__(self):
        self.root = None

    def create(self, root, x):
        if root is None:
            return Node(x)
        elif x < root.data:
            root.left = self.create(root.left, x)
        else:
            root.right = self.create(root.right, x)
        return root

    def insert(self, x):
        self.root = self.create(self.root, x)
        
    def sum(self, root):
        if root is None:
            return 0
        else:
            return root.data + self.sum(root.left) + self.sum(root.right)
        
    def even_sum(self,root):
        if root is None:
            return 0
        if root.data%2==0:
            return self.even_sum(root.left)+self.even_sum(root.right)+root.data
        else:
            return self.even_sum(root.left)+self.even_sum(root.right)
        
    def odd_sum(self,root):
        if root is None:
            return 0
        if root.data%2!=0:
            return root.data+self.odd_sum(root.left)+self.odd_sum(root.right)
        else:
            return self.odd_sum(root.left)+self.odd_sum(root.right)
        
    def height(self,root):
        if root is None:
            return -1
        return max(self.height(root.left),self.height(root.right))+1

    def balance(self,root):
        return abs((self.height(root.left)) - (self.height(root.right))) <=1

    def count_leaf_nodes(self,root):
        if root is None:
            return 0
        if root.left is None and root.right is None:
            return 1
        return self.count_leaf_nodes(root.left) + self.count_leaf_nodes(root.right)

    def sum_leaf_nodes(self,root):
        if root is None:
            return 0
        if root.left is None and root.right is None:
            return root.data
        return self.sum_leaf_nodes(root.left) + self.sum_leaf_nodes(root.right)

    def search(self,root,x):
        if root==None:
            return "Not found"
        if root.data== x:
            return "found"
        if root.data>x:
            return self.search(root.left,x)
        else:
            return self.search(root.right,x)
        

    def depth(self, root, x, c=0):
        if root is None:
            return -1
        if root.data == x:
            return c
        if root.data > x:
            return self.depth(root.left, x, c+1)
        else:
            return self.depth(root.right, x, c+1)
        
    def leftview(self,root,c,l):
        if(root==None):
            return
        if(c not in l):
            l.append(c)
            print(root.data,end=" ")
            self.leftview(root.left,c+1,l)
            self.leftview(root.right,c+1,l)

    def rightview(self,root,c,l):
        if(root==None):
            return
        if(c not in l):
            l.append(c)
            print(root.data)
        self.rightview(root.right,c+1,l)
        self.rightview(root.left,c+1,l)
        
    def top_view(self,root):
        if root is None:
            return
        d = {}
        q=[]
        q=([(root, 0)])
        while (): 
            root=q[0][0]
            if(root.left!=None):
                q.append((root.left,q[0][1]-1))
            if(root.right!=None):
                q.append((root.right,q[0][1]+1))
            if(q[0][1] not in d):
                d[q[0][1]]=root.data
            q.pop(0)
                
        for i in sorted(d):
            print(d[i],end='' '')

        
t1 = Tree()
t1.insert(10)
t1.insert(5)
t1.insert(20)
t1.insert(7)
t1.insert(4)
t1.insert(8)
t1.insert(25)
t1.insert(6)
t1.insert(19)
t1.insert(23)
t1.insert(9)

print("sum:")
total_sum = t1.sum(t1.root)
print(total_sum)

print(t1.sum(t1.root.left))#printing left sub tree sum

print((t1.sum(t1.root.left))-(t1.sum(t1.root.right))) #printing diff of left and right subtrees

print("even sum:")
print(t1.even_sum(t1.root))

print("odd sum:")
print(t1.odd_sum(t1.root))

print("even and odd sum diff:")
print((t1.odd_sum(t1.root))-(t1.even_sum(t1.root)))#diff b/w even and odd sum of subtree

print("height of tree")
print(t1.height(t1.root))

print("balanced tree:")
print(t1.balance(t1.root))

print("count")
print(t1.count_leaf_nodes(t1.root))

print("sum of leaf nodes")
print(t1.sum_leaf_nodes(t1.root))

print("depth of tree") 
print(t1.depth(t1.root,15))

print("searching an element")
print(t1.search(t1.root,15))

print("depth of tree") 
print(t1.depth(t1.root,2))

print("leftview")
t1.leftview(t1.root,0,[])

print("rightview")
t1.rightview(t1.root,0,[])

print("topview")
t1.top_view(t1.root)




#diff of even and odd sum ..modified code...

'''
def even_sum(self,root):
        if root is None:
            return 0
        if root.data%2==0:
            return self.even_sum(root.left)+self.even_sum(root.right)+root.data
        else:
            return root.data-self.even_sum(root.left)+self.even_sum(root.right)
'''
