'''ip: 4
op:  ----a----
       ---aba---
       --abcba--
       -abcdcba-'''
def print_pattern(n):
    for i in range(n):
        l = '-' * (n - i - 1)
        for j in range(i + 1):
            l+= chr(97 + j)
        for j in range(i, 0, -1):
            l += chr(97 + j - 1)
        l += '-' * (n - i - 1)
        print(l)
print_pattern(5)

