#print the length of longest substring present in a string with the sequence of alphabets..... ip: xyzabcdefklmnopqefgh ....... op:7
'''def long_sequence(s):
    max_length = 0
    current_length = 1

    for i in range(1, len(s)):
        if ord(s[i]) == ord(s[i-1]) + 1:
            current_length += 1
        else:
            max_length = max(max_length, current_length)
            current_length = 1  

    max_length = max(max_length, current_length)
    return max_length

input_str = "xyzabcdefklmnopqefgh"

longest_sequence_length = long_sequence(input_str)

print(longest_sequence_length)'''

a=input()
m=0
c=1
for i in range(len(a)-1):
    if(ord(a[i]) ==ord(a[i+1])-1):
        c=c+1
    else:
        if(c>m):
            m=c
        c=1
if(c>m):
    m=c
print(m)    
