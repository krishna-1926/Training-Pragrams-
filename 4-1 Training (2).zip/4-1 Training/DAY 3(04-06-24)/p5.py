#take list from user ...compare with the week days.. a pen should be bought and sold once a week
''' ip: 15 3 2  7 8 9
         m t w t f s
    op: 6
     ip: 5 3 2 7 8 9
    op: 6
    ip: 5 4 2 9 7 1
    op: 7
    ip:  9 8 7 6 5 4 
    op: 0
'''
li=[]
res=[]
for i in range(6):
    li.append(int(input()))
for i in range(6):
    for j in range(i,6):
        if li[i]<li[j]:
            res.append(li[j]-li[i])
if res!=[]:
    print(max(res))
else:
    print(0)

    
