'''print the pattern
*  *   *  *   *
*  1   2   3  *
*  4   5   6  *
*  7   8   9  *
*  *   *   *  *
'''
def print_pattern():
    s = 5  
    c = 1
    for i in range(s):
        for j in range(s):
            if i == 0 or i == s-1 or j == 0 or j == s-1:
                print('*', end='  ')
            else:
                print(c, end='  ')
                c += 1
        print() 

print_pattern()

'''
val=1
for i in range(5):
    for j in range(5):
        if i==0 or j==0 or i==4 or j==4:
            print("*",end=" ")
        else:
            print(val,end=" ")
            val+=1
    print(" ")
    '''
