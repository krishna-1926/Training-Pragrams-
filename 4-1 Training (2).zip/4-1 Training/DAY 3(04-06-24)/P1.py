# IP: khoor      3     op: hello.............. for the given input number, print left alphabet of each alphabet...
'''def caesar_cipher_decrypt(text, shift):
    decrypted_text = ""
    for char in text:
        if char.isalpha():
            # Determine if the character is uppercase or lowercase
            ascii_offset = ord('A') if char.isupper() else ord('a')
            # Shift the character and handle wrapping using modulo
            new_char = chr((ord(char) - ascii_offset - shift) % 26 + ascii_offset)
            decrypted_text += new_char
        else:
            decrypted_text += char  
    return decrypted_text
encrypted_text=input()
shift=int(input())
decrypted_text = caesar_cipher_decrypt(encrypted_text, shift)
print(decrypted_text)'''

a='bvec'
b=4
c=b%26
d=''
for i in a:
    if((ord(i)-c)>=97):
        d=d+chr(ord(i)-c)
    else:
        d=d+chr(ord(i)-c+26)
print(d)


    
