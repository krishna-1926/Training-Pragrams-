''' nums
     ip:  [(1,3) (2,5) (4,6)  (6,7)  (5,8)  (7,9) ]

           [5,6,5,4,11,2]

    op: 17
    the time 1 0 clock and 3 o clock, the price we give rs.5... consecutively all .. find the hightest price of sum for possible time to be worked.'''

nums=[(1,3),(2,5),(4,6),(6,7),(5,8),(7,9)]
a=[5,6,5,4,11,2]
b=a.copy()
for i in range(1,len(nums)):
    for j in range(0,i):
        if nums[j][1]<=nums[i][0] and b[i]<b[j]+a[i]:
            b[i]=b[j]+a[i]
print(max(b))
